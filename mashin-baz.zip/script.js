const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let car = { x: 175, y: 500, width: 50, height: 100, speed: 5 };
let obstacles = [];
let score = 0;
let gameOver = false;

// کنترل ماشین
document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowLeft" && car.x > 0) {
    car.x -= car.speed;
  } else if (e.key === "ArrowRight" && car.x < canvas.width - car.width) {
    car.x += car.speed;
  }
});

// ساخت مانع
function createObstacle() {
  let x = Math.random() * (canvas.width - 50);
  obstacles.push({ x: x, y: -100, width: 50, height: 100 });
}

// آپدیت بازی
function update() {
  if (gameOver) return;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // ماشین
  ctx.fillStyle = "red";
  ctx.fillRect(car.x, car.y, car.width, car.height);

  // موانع
  ctx.fillStyle = "blue";
  for (let i = 0; i < obstacles.length; i++) {
    let obs = obstacles[i];
    obs.y += 5;
    ctx.fillRect(obs.x, obs.y, obs.width, obs.height);

    // برخورد
    if (
      car.x < obs.x + obs.width &&
      car.x + car.width > obs.x &&
      car.y < obs.y + obs.height &&
      car.y + car.height > obs.y
    ) {
      gameOver = true;
      alert("بازی تمام شد! امتیاز: " + score);
      document.location.reload();
    }

    if (obs.y > canvas.height) {
      obstacles.splice(i, 1);
      score++;
    }
  }

  // امتیاز
  ctx.fillStyle = "white";
  ctx.font = "20px Tahoma";
  ctx.fillText("امتیاز: " + score, 10, 30);
}

setInterval(update, 30);
setInterval(createObstacle, 2000);
